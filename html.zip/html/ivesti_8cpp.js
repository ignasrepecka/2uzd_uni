var ivesti_8cpp =
[
    [ "ivestiStudentus", "ivesti_8cpp.html#a64a041a2d415933dcd96688fee4fe1ae", null ]
];