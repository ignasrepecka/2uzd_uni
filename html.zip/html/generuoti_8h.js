var generuoti_8h =
[
    [ "calculateStatistics", "generuoti_8h.html#a503f7845adbd106ce5f12288967b544f", null ],
    [ "generuoti", "generuoti_8h.html#a94957e20c03c4fe330cf2081dab701fa", null ]
];