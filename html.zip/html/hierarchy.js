var hierarchy =
[
    [ "calculateStatistics", "classcalculate_statistics.html", null ],
    [ "Studentasl", "class_studentasl.html", null ],
    [ "Zmogus", "class_zmogus.html", [
      [ "Studentas", "class_studentas.html", null ]
    ] ]
];