var include_2calculate_statistics_8h =
[
    [ "calculateStatistics", "classcalculate_statistics.html", "classcalculate_statistics" ]
];