var annotated_dup =
[
    [ "calculateStatistics", "classcalculate_statistics.html", "classcalculate_statistics" ],
    [ "Studentas", "class_studentas.html", "class_studentas" ],
    [ "Studentasl", "class_studentasl.html", "class_studentasl" ],
    [ "Zmogus", "class_zmogus.html", "class_zmogus" ]
];