var sort_students_8h =
[
    [ "compareByAverage", "sort_students_8h.html#ad3ce69e164553a55cef39e110fe6f9ab", null ],
    [ "compareByMedian", "sort_students_8h.html#ab61d7e4b8a1bd065c4dcb12ebed66ba3", null ],
    [ "compareByName", "sort_students_8h.html#ac3a31b2310d65b42b64a422eb9469e94", null ],
    [ "compareBySurname", "sort_students_8h.html#ac9f79a59b71048ff03515ccec1d0ec96", null ],
    [ "sortStudents", "sort_students_8h.html#a2cfe0a117dede4353ff41a851cf0898b", null ]
];