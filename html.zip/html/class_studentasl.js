var class_studentasl =
[
    [ "Studentasl", "class_studentasl.html#ae6abb2611d02f699b4568c1e66c75888", null ],
    [ "~Studentasl", "class_studentasl.html#a475949fe692d43800d5ce77bf66c45e4", null ],
    [ "getBalai", "class_studentasl.html#a819ba99b6a4b096b8ed363d1a61cd775", null ],
    [ "getEgz", "class_studentasl.html#a967a9ab18ae40bf776b1e16d3522ef98", null ],
    [ "getMediana", "class_studentasl.html#ab4cf5977a879c2802dd265a5ea22e97a", null ],
    [ "getPavarde", "class_studentasl.html#afc474c3d352e4f1b1d57d8d146e9a342", null ],
    [ "getVardas", "class_studentasl.html#a74f1b7f3c75468faf1c654ea39462a09", null ],
    [ "getVidurkis", "class_studentasl.html#a74d8e52b2d6ac960c3a352ff9a0f45cd", null ],
    [ "listCalculateStatistics", "class_studentasl.html#a3583bb70a54c64f534f3b9aabf5ac76d", null ],
    [ "readStudent", "class_studentasl.html#a0d09b3d5ba5eaf26b98446f1a48464fc", null ]
];