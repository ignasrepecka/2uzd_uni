var failas_8cpp =
[
    [ "isFailo", "failas_8cpp.html#a001f8e13e1f518aaeb95b63e6a9e9c5e", null ]
];