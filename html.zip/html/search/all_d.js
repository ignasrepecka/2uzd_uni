var searchData=
[
  ['_7ecalculatestatistics_0',['~calculateStatistics',['../classcalculate_statistics.html#acf92b8df7e9c76cd8913f8cd38222c9d',1,'calculateStatistics']]],
  ['_7estudentas_1',['~Studentas',['../class_studentas.html#a63e449e0f51a0b14340d02ee71b4be23',1,'Studentas']]],
  ['_7estudentasl_2',['~Studentasl',['../class_studentasl.html#a475949fe692d43800d5ce77bf66c45e4',1,'Studentasl']]],
  ['_7ezmogus_3',['~Zmogus',['../class_zmogus.html#ac5615bf607a8f2f1b303ffa04328d24d',1,'Zmogus']]]
];
