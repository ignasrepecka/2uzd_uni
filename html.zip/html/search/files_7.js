var searchData=
[
  ['sortstudents_2ecpp_0',['sortStudents.cpp',['../sort_students_8cpp.html',1,'']]],
  ['sortstudents_2eh_1',['sortStudents.h',['../sort_students_8h.html',1,'']]],
  ['strat_2ecpp_2',['strat.cpp',['../strat_8cpp.html',1,'']]],
  ['strat_2eh_3',['strat.h',['../strat_8h.html',1,'']]],
  ['studentai_2eh_4',['studentai.h',['../studentai_8h.html',1,'']]]
];
