var searchData=
[
  ['calculatestatistics_0',['calculateStatistics',['../classcalculate_statistics.html',1,'']]]
];
