var searchData=
[
  ['readstudent_0',['readStudent',['../class_studentas.html#a56cfe16f164d76b63f50898ef0a6403a',1,'Studentas::readStudent()'],['../class_studentasl.html#a0d09b3d5ba5eaf26b98446f1a48464fc',1,'Studentasl::readStudent()']]]
];
