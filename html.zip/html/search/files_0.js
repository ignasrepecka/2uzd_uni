var searchData=
[
  ['calculatestatistics_2ecpp_0',['calculateStatistics.cpp',['../calculate_statistics_8cpp.html',1,'(Global Namespace)'],['../src_2calculate_statistics_8cpp.html',1,'(Global Namespace)']]],
  ['calculatestatistics_2eh_1',['calculateStatistics.h',['../calculate_statistics_8h.html',1,'(Global Namespace)'],['../include_2calculate_statistics_8h.html',1,'(Global Namespace)']]]
];
