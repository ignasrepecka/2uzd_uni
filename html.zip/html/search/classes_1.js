var searchData=
[
  ['studentas_0',['Studentas',['../class_studentas.html',1,'']]],
  ['studentasl_1',['Studentasl',['../class_studentasl.html',1,'']]]
];
