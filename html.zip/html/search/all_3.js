var searchData=
[
  ['generatefile_0',['generateFile',['../generate_file_8cpp.html#af1b49d553e2ac7e158b3f787b637f0fa',1,'generateFile(int n, int fileNum):&#160;generateFile.cpp'],['../generate_file_8h.html#af1b49d553e2ac7e158b3f787b637f0fa',1,'generateFile(int n, int fileNum):&#160;generateFile.cpp']]],
  ['generatefile_2ecpp_1',['generateFile.cpp',['../generate_file_8cpp.html',1,'']]],
  ['generatefile_2eh_2',['generateFile.h',['../generate_file_8h.html',1,'']]],
  ['generuoti_3',['generuoti',['../generuoti_8cpp.html#abdbff165951e889c79ec78e8abb1dc64',1,'generuoti(int a):&#160;generuoti.cpp'],['../generuoti_8h.html#a94957e20c03c4fe330cf2081dab701fa',1,'generuoti(int n, int a):&#160;generuoti.h']]],
  ['generuoti_2ecpp_4',['generuoti.cpp',['../generuoti_8cpp.html',1,'']]],
  ['generuoti_2eh_5',['generuoti.h',['../generuoti_8h.html',1,'']]],
  ['getbalai_6',['getBalai',['../class_studentas.html#a19cd66744d93ab82074bb7093c8c98aa',1,'Studentas::getBalai()'],['../class_studentasl.html#a819ba99b6a4b096b8ed363d1a61cd775',1,'Studentasl::getBalai()']]],
  ['getegz_7',['getEgz',['../class_studentas.html#a2f9dcb2fef2e6b3dbc1581779a90a68a',1,'Studentas::getEgz()'],['../class_studentasl.html#a967a9ab18ae40bf776b1e16d3522ef98',1,'Studentasl::getEgz()']]],
  ['getmediana_8',['getMediana',['../class_studentas.html#a75eb0996687d5e740b44e28e6e1bfc5f',1,'Studentas::getMediana()'],['../class_studentasl.html#ab4cf5977a879c2802dd265a5ea22e97a',1,'Studentasl::getMediana()']]],
  ['getpavarde_9',['getPavarde',['../class_zmogus.html#ac50d1e325af387bb385eb88bb7ff42b7',1,'Zmogus::getPavarde()'],['../class_studentasl.html#afc474c3d352e4f1b1d57d8d146e9a342',1,'Studentasl::getPavarde()']]],
  ['getvardas_10',['getVardas',['../class_zmogus.html#a4a580af3507a2d27efe978d5be0075ab',1,'Zmogus::getVardas()'],['../class_studentasl.html#a74f1b7f3c75468faf1c654ea39462a09',1,'Studentasl::getVardas()']]],
  ['getvidurkis_11',['getVidurkis',['../class_studentas.html#ac0a7e980225142cb5445f6b0432191b3',1,'Studentas::getVidurkis()'],['../class_studentasl.html#a74d8e52b2d6ac960c3a352ff9a0f45cd',1,'Studentasl::getVidurkis()']]]
];
