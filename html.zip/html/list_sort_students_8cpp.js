var list_sort_students_8cpp =
[
    [ "compareByAverage", "list_sort_students_8cpp.html#a597aab54f9771d41d7ee9ad3ecee4640", null ],
    [ "compareByMedian", "list_sort_students_8cpp.html#a3b5950ee0fd7b7f4d8631e120d2f33dd", null ],
    [ "compareByName", "list_sort_students_8cpp.html#aa8b1cef81b96ce974db1a10ef51abab9", null ],
    [ "compareBySurname", "list_sort_students_8cpp.html#affd3284291b27370f64975440bc53769", null ],
    [ "listSortStudents", "list_sort_students_8cpp.html#a2e7693e6cccb143a7e069c98af147e1c", null ]
];