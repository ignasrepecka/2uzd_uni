var classcalculate_statistics =
[
    [ "calculateStatistics", "classcalculate_statistics.html#aebfb9279b536282bd3f479eebd57ccb2", null ],
    [ "~calculateStatistics", "classcalculate_statistics.html#acf92b8df7e9c76cd8913f8cd38222c9d", null ]
];