var class_studentas =
[
    [ "Studentas", "class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539", null ],
    [ "~Studentas", "class_studentas.html#a63e449e0f51a0b14340d02ee71b4be23", null ],
    [ "Studentas", "class_studentas.html#aef0484fe46cf05746f8ffc0d083fcf3e", null ],
    [ "calculateStatistics", "class_studentas.html#a93008520fb56cf9182351fcafc99d206", null ],
    [ "getBalai", "class_studentas.html#a19cd66744d93ab82074bb7093c8c98aa", null ],
    [ "getEgz", "class_studentas.html#a2f9dcb2fef2e6b3dbc1581779a90a68a", null ],
    [ "getMediana", "class_studentas.html#a75eb0996687d5e740b44e28e6e1bfc5f", null ],
    [ "getVidurkis", "class_studentas.html#ac0a7e980225142cb5445f6b0432191b3", null ],
    [ "operator=", "class_studentas.html#a25bcc531503d3bc490dab4a656e3b8e9", null ],
    [ "readStudent", "class_studentas.html#a56cfe16f164d76b63f50898ef0a6403a", null ],
    [ "operator<<", "class_studentas.html#a4062cbd3f4c44fac2063e38cfa00a8cf", null ],
    [ "operator>>", "class_studentas.html#ac63003b577b137ac6ad5b1fb176bd59a", null ]
];