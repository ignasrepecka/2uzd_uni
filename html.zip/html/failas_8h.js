var failas_8h =
[
    [ "isFailo", "failas_8h.html#ad727f8e8b99851f7fbbb12c250d24be5", null ]
];