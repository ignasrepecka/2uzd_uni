var list_strat_8cpp =
[
    [ "listStrat", "list_strat_8cpp.html#ab6ac5a822a408ae4eab24b6702e30219", null ]
];