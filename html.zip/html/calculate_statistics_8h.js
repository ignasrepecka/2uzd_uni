var calculate_statistics_8h =
[
    [ "Zmogus", "class_zmogus.html", "class_zmogus" ],
    [ "Studentas", "class_studentas.html", "class_studentas" ]
];