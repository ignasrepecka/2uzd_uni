var list_calculate_statistics_8h =
[
    [ "Studentasl", "class_studentasl.html", "class_studentasl" ]
];