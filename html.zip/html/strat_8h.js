var strat_8h =
[
    [ "strat", "strat_8h.html#ad15961a7c6320526da16caaf5ddffa37", null ]
];