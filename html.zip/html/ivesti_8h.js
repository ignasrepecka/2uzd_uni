var ivesti_8h =
[
    [ "ivestiStudentus", "ivesti_8h.html#a64a041a2d415933dcd96688fee4fe1ae", null ]
];