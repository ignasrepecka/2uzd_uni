var list_strat_8h =
[
    [ "listStrat", "list_strat_8h.html#ab6ac5a822a408ae4eab24b6702e30219", null ]
];