var strat_8cpp =
[
    [ "strat", "strat_8cpp.html#ad15961a7c6320526da16caaf5ddffa37", null ]
];