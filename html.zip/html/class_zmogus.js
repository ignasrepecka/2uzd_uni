var class_zmogus =
[
    [ "Zmogus", "class_zmogus.html#aa7a8ba4d3c4778f9b35d59eef3e72574", null ],
    [ "~Zmogus", "class_zmogus.html#ac5615bf607a8f2f1b303ffa04328d24d", null ],
    [ "calculateStatistics", "class_zmogus.html#a92cdfd5df90e5d27a737dc5a32055a51", null ],
    [ "getPavarde", "class_zmogus.html#ac50d1e325af387bb385eb88bb7ff42b7", null ],
    [ "getVardas", "class_zmogus.html#a4a580af3507a2d27efe978d5be0075ab", null ],
    [ "pavarde", "class_zmogus.html#a99cc96defe5d014db052cc754e989b16", null ],
    [ "vardas", "class_zmogus.html#a4d456bf4fea70f08e0b26517576cfbc0", null ]
];