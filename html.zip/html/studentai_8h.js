var studentai_8h =
[
    [ "isFailo", "studentai_8h.html#a8364b7ddd1142c518726f0b93b843345", null ],
    [ "listIsFailo", "studentai_8h.html#aa43e6ed5d160b538ab75c103645abbc5", null ]
];